import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/user/user.service';
import { User } from '../models/User';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  user = new User();

  constructor(private userService : UserService) { }

  ngOnInit(): void {
  }

  registerUser(){
    console.log(this.user)
    this.userService.registerUserRemote(this.user).subscribe(response =>{
      console.warn("data saved successfully!");
    })
  }

}
