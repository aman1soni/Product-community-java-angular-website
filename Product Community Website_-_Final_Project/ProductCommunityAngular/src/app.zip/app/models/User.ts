export class User{
    // String username;
    // String firstname;
    // String lastname;
    // String email;
    // String password;

    userId:number;
    username:string;
    firstname:string;
    lastname:string;
    email:string;
    password:string;

    constructor(){}

    // constructor(userId:number,
    //             username:string,
    //             firstname:string,
    //             lastname:string,
    //             email:string,
    //             password:string){

    //     this.userId = userId;
    //     this.username = username;
    //     this.firstname = firstname;
    //     this.lastname = lastname;
    //     this.email = email;
    //     this.password = password;
    // }
}